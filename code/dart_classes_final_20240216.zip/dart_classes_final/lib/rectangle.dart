
class Rectangle {
  const Rectangle(this.width, this.height);
  final double width;
  final double height;

  double getArea() {
    return width * height;
  }

  double get area {
    return width * height;
  }
  // same with arrow-syntax:
  //double get area => width * height;
}