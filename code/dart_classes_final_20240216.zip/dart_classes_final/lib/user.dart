class User {
  // c-tor with "initializing formal parameters"
  //User(this._firstName, this.lastName);

  //c-tor with "initializer list"
  User(String fName, String lName) : _firstName = fName, lastName = lName {
    print("new user created: $fullName");
    numberOfUsers++;
  }

  // named c-tor
  User.withFullName(String fName) : _firstName = "", lastName = "" {
    fullName = fName;
    numberOfUsers++;
  }

  static int numberOfUsers = 0;

  // encalsulated field "firstName"
  String _firstName;

  String get firstName => _firstName;

  set firstName(String value) {
    // do not allow to set firstName to an empty String:
    if (value.length > 0) {
      _firstName = value;
    }
  }

  String lastName;

  String getFullName() {
    return "$firstName $lastName";
  }
  // same with "arrow syntax"
  //String getFullName() => "$firstName $lastName";

  // getter:
  String get fullName {
    return "$firstName $lastName";
  }
  // same with "arrow syntax"
  //String get fullName => getFullName();

  void setFullName(String name) {
    var parts = name.split(" ");
    if (parts.length == 2) {
      firstName = parts[0];
      lastName = parts[1];
    }
  }

  // setter
  set fullName(String name) {
    setFullName(name);
  }

  @override
  String toString() => "User $firstName $lastName";
}

class PayingUser extends User {
  //PayingUser(String fName, String lName, String ib) :  iban = ib, super (fName, lName);
  PayingUser(String fName, String lName, this.iban) : super(fName, lName);

  // At the time where I had no encapsulation for firstName I defined also
  //PayingUser(super.firstName, super.lastName, this.iban);
  // Now with encapsulation I wondered why there is no super._firstName needed here.
  // Finally I saw that it does not depend on the names at all, and that is very strange for me ?!
  //PayingUser(super.a, super.b, this.iban);

  String iban;

  @override
  String toString() => "PayingUser $firstName $lastName $iban";

  void debit() {
    print("debit called for user $fullName");
  }
}
