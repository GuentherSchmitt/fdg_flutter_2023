
import 'rectangle.dart';
import 'user.dart';

void main(List<String> args) {
  //var user1 = new User("Max", "Mustermann");
  // in dart new is not needed:
  var user1 = new User("Max", "Mustermann");
  print(user1.firstName);
  print(user1.lastName);

  // write access to the fields:
  user1.firstName = "Fritz";
  user1.lastName = "Fischer";

  // test fullName setter
  //user1.setFullName("Hans Maier");
  user1.fullName = "Heinz Müller";
  print(user1.firstName);
  print(user1.lastName);

  // test fullName getter
  print(user1.getFullName());
  print(user1.fullName);
  
  // test named c-tor
  var user2 = User.withFullName("Frank Schmitt");
  print(user2.firstName);
  print(User.numberOfUsers);

  var rect = const Rectangle(200, 50);  
  print("calling method getArea: ${rect.getArea()}");
  print("calling getter area: ${rect.area}");
  var rect2 = const Rectangle(100, 50); 
  var rect3 = const Rectangle(200, 50); 

  print(rect.hashCode);
  print(rect2.hashCode);
  print(rect3.hashCode);

  User userX = User("firstX", "lastX");  
  print(userX);  // same as print(userX.ToString());

 // User userX = User("firstX", "lastX");  // same as   var userX = User("firstX", "lastX");              
  PayingUser userY = PayingUser("firstY", "lastY", "ibanY");  // also possible with var  
  User userZ = PayingUser("firstZ", "lastZ", "ibanZ");

  print(userX);
  print(userY);
  print(userZ);

  userY.debit();
  //userZ.debit();  // error "The method 'debit' isn't defined for the type 'User'."

  if (userZ is PayingUser) {
    userZ.debit();
  }

  testList();
}

void testList() {
  List<int> intList = [1, 2, 3, 5, 7, 11, 13];
  List<User> userList = [User.withFullName("Franz Maier")];

  print("last in intList is ${intList.last}");
  print("intList is $intList");

  userList.add(PayingUser("Willi", "Zahn", "ibanWZ"));
  for (var user in userList) {
    print("$user");
  }
  userList.removeLast();
}
