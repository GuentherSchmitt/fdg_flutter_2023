// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, avoid_print

import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

void handleOnPressed() {
  print("in handleOnPressed ...");
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Color.fromARGB(255, 166, 189, 231),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Text('Hello World!',
                  style: TextStyle(
                      color: Colors.red,
                      fontSize: 24,
                      fontStyle: FontStyle.italic)),

              OutlinedButton(
                  style: OutlinedButton.styleFrom(
                      backgroundColor: Colors.yellow,
                      fixedSize: Size(150, 50),
                      elevation: 10),
                  onPressed: () {
                    print("in anonymous function for onPressed ...");
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.download),
                      SizedBox(width: 10),
                      Text("Download"),
                    ],
                  )),

              // use some other butten types:
              OutlinedButton(
                  onPressed: handleOnPressed,
                  child: Text("OutlinedButton without style")),
              ElevatedButton(
                  onPressed: handleOnPressed, child: Text("ElevatedButton")),
              IconButton(
                  onPressed: handleOnPressed, icon: Icon(Icons.pedal_bike)),

              // when executed on Chrome, the following network image is not correctly displayed.
              Image.network(
                  "https://fdg-ab.de/wp-content/uploads/2021/03/logo_fdg_neu_freigestellt.png",
                  width: 150),

              ClipRRect(
                  borderRadius: BorderRadius.all(Radius.circular(30)),
                  // next 2 lines would round only top-left and bottom-right corners
                  //  borderRadius: BorderRadius.only(
                  //  topLeft: Radius.circular(30), bottomRight: Radius.circular(30)),
                  child: Image.asset("assets/images/snoopy_christmas.jpg",
                      width: 250)),

              // next line would show snoopy_laptop.jpg without oval clip
              //Image.asset("assets/images/snoopy_laptop.jpg", width: 100),

              ClipOval(
                  child: Image.asset("assets/images/snoopy_laptop.jpg",
                      width: 100)),
            ],
          ),
        ),
      ),
    );
  }
}
