// ignore_for_file: unused_local_variable

void main() {
  // --- int and double ---

  int i = 23;
  double d = 24;

  double d1 = 2.34;
  //int i1 = 2.34;      // double cannot be assigned to int

  //d = i;              // int cannot be assigned to double
  d = i.toDouble();

  //i = d;              // double cannot be assigned to int
  i = d.toInt();        // toInt() truncates the decimal places

  //d = i + i;          // int cannot be assigned to double
  d = i + d;
  //i = i + d;          // double cannot be assigned to int

  // --- special functions for int ---

  print("--- testing int.toRadixString and shift operators << >>---");
  i = 30;
  print(i.toRadixString(16));
  print(i.toRadixString(8));
  print(i.toRadixString(7));
  print(i.toRadixString(2));
  i = i >> 1;
  // next line makes the same as last line:
  // i >>= 1;
  print(i.toRadixString(2));
  print(i);
  i = i << 3;
  print(i.toRadixString(2));
  print(i);

  // --- ceil (Decke) and floor (Boden) for num ---

  print("--- testing num.ceil and num.floor ---");
  num n1 = -1.6;
  num n2 = 1.6;
  print("n1: $n1, ceil: ${n1.ceil()}, floor: ${n1.floor()}");
  print("n2: $n2, ceil: ${n2.ceil()}, floor: ${n2.floor()}");
}
