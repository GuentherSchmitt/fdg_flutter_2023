void main(List<String> args) {
  print('Hello World!');

  // for-loop like in C:
  for (int i = 0; i < args.length; i++) {
    print(args[i]);
  }

  // for-loop more frequently used in Dart:
  for (String arg in args) {
    print(arg);
  }
}
