import 'dart:math';

void main() {
  double d = sin(3.14);
  print(d);
  print(d.toStringAsFixed(10));

  d = sin(pi);
  print(d);
  print(d.toStringAsFixed(10));
}

