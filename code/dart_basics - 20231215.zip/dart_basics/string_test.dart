void main() {
  // --- String and String-Interpolation ---

  String s = 'hello world';

  s = "It's me"; // you can either use " or ' to surround strings
  s = 'It\'s me'; // backslash is the "escape character" in strings
  s = 'c:\\flutter\\sdk'; // \\ stands for \ inside the string
  s = '1st line\n2nd line'; // \n is new line for multi-line strings

  s = "hello";
  s = s + " world"; // "hello world"
  s += "!"; // "hello world!""

  double d = 1.234567;
  //s = d;               // double cannot be assigned to string
  s = d.toString();

  s = "d is " + d.toString(); // "d is 1.234567"
  s = "d is " + d.toStringAsFixed(2); // "d is 1.23"

  // next lines use String-Interpolation:
  s = "d is $d !"; // "d is 1.234567 !"
  s = "d + 1 is ${d + 1} !"; // "d + 1 is 2.234567 !"
  s = "d is ${d.toStringAsFixed(1)}"; // "d is 1.2"

  num n = 3;
  s = "n is " + n.toStringAsFixed(2); // "n is 3.00"
}
