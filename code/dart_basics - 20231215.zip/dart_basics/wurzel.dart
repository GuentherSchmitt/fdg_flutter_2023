import 'dart:math';

void main(List<String> args) {
  for (int i = 0; i < args.length; i++) {
    String arg = args[i];
    double? d = double.tryParse(arg);
    if (d == null) {
      print("argument '$arg' is not a number.");
    } else if (d < 0) {
      print("cannot calculate square root from negative number '$arg'.");
    } else {
      String rounded = sqrt(d).toStringAsFixed(4);
      print("square root of '$arg' rounded to 4 decimal places is '$rounded'.");
      // instead of the last 2 lines you could also write the following quite long line
      //print("square root of $arg rounded to 4 decimal places is '${sqrt(d).toStringAsFixed(4)}'.");
    }
  }
}
