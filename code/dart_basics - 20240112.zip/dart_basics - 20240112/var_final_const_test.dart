void main(List<String> args) {

  // --- variable declaration with var ---

  // int x = 1;
  // double y = 1.23;
  // List<String> names = ["Franz", "Frank"];

  var x = 1;
  var y = 1.23;
  var names = ["Franz", "Frank"];

  print(x.runtimeType);
  print(y.runtimeType);
  print(names.runtimeType);

  for (var name in names) {
    print(name);
  }

  // --- final variables ---

  final int myInt = 1;
  final List<String> myList = ["a", "bb"];

  //myInt = 5;             // error: The final variable 'myInt' can only be set once.

  //myList = ["x", "yy"];  // error: The final variable 'myList' can only be set once.
  myList.add("ccc"); // that's ok, we do not assign a new list

  final myDouble = 1.5; // short for "final double myDouble1 = 1.5;"

  print(myInt.runtimeType);
  print(myDouble.runtimeType);
  print(myList.runtimeType);

  // --- difference final vs. const ---

  //const int cInt;        // error: The constant 'cInst' must be initialized.

  const int cInt1 = 23;

  final int fInt;

  fInt = 23;

  //fInt = 1;

  //cInt1 = 1;

  // to avoid warnings "variable not used" above
  print("$cInt1 $fInt");

  const names1 = ["Franz", "Frank"];
  names1.add("xxx");
  //names1 = ["yyy"];
}
