
void main() {

  bool b = false;
  print("not b is ${!b}"); // "not b is true"

  int i = 5;
  b = (i > -1);
  b = (i > -1) && (i < 1);
  b = (i <= -1) || (i >= 1);

  String result;
  if (i.isEven) {
    result = "gerade";
  } else {
    result = "ungerade";
  }
  print(result);

  // shorter with a conditional expression

  print(i.isEven ? "gerade" : "ungerade");

}