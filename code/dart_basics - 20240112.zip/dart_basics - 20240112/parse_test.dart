// --- parse strings for integers and discuss nullable types ---

void main(List<String> args) {

  print(int.tryParse("2"));
  print(int.tryParse("a"));

  int? parsed = int.tryParse("2");
  if (parsed != null) {
    print(parsed.isEven);
  }

  print(double.parse("4"));
}

