void main() {
  var weekDay = getWorkDayOfDate(1950, 12, 20);
  print(weekDay);
}

// int getWorkDayOfDate(int year, int month, int day) {
//   return DateTime(year, month, day).weekday;
// }

int getWorkDayOfDate(int year, int month, int day) =>
    DateTime(year, month, day).weekday;
