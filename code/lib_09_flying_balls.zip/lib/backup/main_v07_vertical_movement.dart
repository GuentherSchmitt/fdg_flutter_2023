// ignore_for_file: avoid_print

import 'dart:async';

import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(home: MainPage());
  }
}

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  double leftYellow = 50;
  double topYellow = 100;
  double widthYellow = 200;
  double heightYellow = 100;
  double speedX = 2;
  double speedY = 2;
  double marginRight = 0;
  double marginBottom = 0;
  double borderWidth = 10;
  double speedFactor = 1;
  Color greenColor = Colors.green;
  double leftGreen = 200;
  double topGreen = 150;

  @override
  void initState() {
    Timer.periodic(const Duration(milliseconds: 20), timerCallback);
    super.initState();
  }

  void timerCallback(Timer timer) {
    var screenWidth = MediaQuery.of(context).size.width;

    setState(() {
      leftYellow += speedX * speedFactor;
      var maxLeft = screenWidth - marginRight - widthYellow - 2 * borderWidth;
      if (leftYellow > maxLeft) {
        leftYellow = maxLeft;
        speedX = -speedX;
      }
      if (leftYellow < 0) {
        leftYellow = 0;
        speedX = -speedX;
      }

      topYellow += speedY * speedFactor;
      var maxTop = getMainBoxHeight() - marginBottom - heightYellow - 2 * borderWidth;
      if (topYellow > maxTop) {
        topYellow = maxTop;
        speedY = -speedY;
      }
      if (topYellow < 0) {
        topYellow = 0;
        speedY = -speedY;
      }
    });
  }

  double getMainBoxHeight() {
    var screenHeight = MediaQuery.of(context).size.height;
    return screenHeight - 150;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        centerTitle: true,
        title: const Text("Flying Balls"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            //Expanded(
            SizedBox(
              height: getMainBoxHeight(),
              child: GestureDetector(
                onPanUpdate: (details) {
                  setState(() {
                    marginRight -= details.delta.dx;
                    if (marginRight < 0) {
                      marginRight = 0;
                    }
                    marginBottom -= details.delta.dy;
                    if (marginBottom < 0) {
                      marginBottom = 0;
                    }
                  });
                },
                child: Container(
                    margin: EdgeInsets.fromLTRB(0, 0, marginRight, marginBottom),
                    height: 600,
                    decoration: BoxDecoration(
                        color: Colors.black,
                        border:
                            Border.all(color: Colors.grey, width: borderWidth)),
                    child: Stack(
                      children: [
                        Positioned(
                            top: topGreen,
                            left: leftGreen,
                            child: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    greenColor = Colors.red;
                                  });
                                },
                                onPanUpdate: (details) {
                                  setState(() {
                                    leftGreen += details.delta.dx;
                                    topGreen += details.delta.dy;
                                  });
                                },
                                child: Container(
                                  width: 100,
                                  height: 150,
                                  color: greenColor,
                                ))),
                        Positioned(
                            top: topYellow,
                            left: leftYellow,
                            child: Container(
                              width: widthYellow,
                              height: heightYellow,
                              color: Colors.yellow,
                            )),
                      ],
                    )),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.lightBlue,
                          foregroundColor: Colors.white),
                      onPressed: () {},
                      child: const Text("Reset")),
                  Slider(
                    min: 0,
                    max: 5,
                    value: speedFactor,
                    onChanged: (value) {
                      setState(() {
                        speedFactor = value;
                      });
                    },
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
