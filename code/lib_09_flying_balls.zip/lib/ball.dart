import 'dart:math';

import 'package:flutter/material.dart';

class Ball {
  static double speedFactor = 1;
  static double yAcceleration = 0.0;
  double left = 0;
  double top = 100;
  double diameter = 50;
  double speedX = 2;
  double speedY = 2;
  Color color = Colors.yellow;

  Ball() {
    var random = Random();
    top = 50 + 200 * random.nextDouble();
    diameter = 2 + 40 * random.nextDouble();
    speedX = 0.5 + 4 * random.nextDouble();
    speedY = 0.5 + 4 * random.nextDouble();
    color = Color.fromARGB(255, random.nextInt(256), random.nextInt(256), random.nextInt(256));
  }

  move(double stackWidth, double stackHeight) {
          left += speedX * speedFactor;
      var maxLeft = stackWidth - diameter;
      if (left > maxLeft) {
        left = maxLeft;
        speedX = -speedX;
      }
      if (left < 0) {
        left = 0;
        speedX = -speedX;
      }

      speedY = speedY + yAcceleration;
      top += speedY * speedFactor;
      var maxTop =
          stackHeight - diameter;
      if (top > maxTop) {
        top = maxTop;
        speedY = -speedY;
      }
      if (top < 0) {
        top = 0;
        speedY = -speedY;
      }

  }
}