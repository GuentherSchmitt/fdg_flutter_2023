import 'rectangle.dart';
import 'user.dart';

void main(List<String> args) {
  //var user1 = new User("Max", "Mustermann");
  // in dart new is not needed:
  var user1 = new User("Max", "Mustermann");
  print(user1.firstName);
  print(user1.lastName);

  // write access to the fields:
  user1.firstName = "Fritz";
  user1.lastName = "Fischer";

  // test fullName setter
  //user1.setFullName("Hans Maier");
  user1.fullName = "Heinz Müller";
  print(user1.firstName);
  print(user1.lastName);

  // test fullName getter
  print(user1.getFullName());
  print(user1.fullName);

  // test named c-tor
  var user2 = User.withFullName("Frank Schmitt");
  print(user2.firstName);
  print(User.numberOfUsers);

  var rect = Rectangle(200, 50);
  print("calling method getArea: ${rect.getArea()}");
  print("calling setter area: ${rect.area}");
}
