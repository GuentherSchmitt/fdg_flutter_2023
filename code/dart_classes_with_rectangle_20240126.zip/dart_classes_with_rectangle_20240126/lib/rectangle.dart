
class Rectangle {
  Rectangle(this.width, this.height);
  double width;
  double height;

  double getArea() {
    return width * height;
  }

  double get area {
    return width * height;
  }
  // same with arrow-syntax:
  //double get area => width * height;
}
