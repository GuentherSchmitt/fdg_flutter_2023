class User {
  // c-tor with "initializing formal parameters"
  //User(this._firstName, this.lastName);

  //c-tor with "initializer list"
  User(String fName, String lName) : _firstName = fName, lastName = lName {
    print("new user created: $fullName");
    numberOfUsers++;
  }

  // named c-tor
  User.withFullName(String fName) : _firstName = "", lastName = "" {
    fullName = fName;
    numberOfUsers++;
  }

  static int numberOfUsers = 0;

  // encalsulated field "firstName"
  String _firstName;

  String get firstName => _firstName;

  set firstName(String value) {
    // do not allow to set firstName to an empty String:
    if (value.length > 0) {
      _firstName = value;
    }
  }

  String lastName;

  String getFullName() {
    return "$firstName $lastName";
  }
  // same with "arrow syntax"
  //String getFullName() => "$firstName $lastName";

  // getter:
  String get fullName {
    return "$firstName $lastName";
  }
  // same with "arrow syntax"
  //String get fullName => getFullName();

  void setFullName(String name) {
    var parts = name.split(" ");
    if (parts.length == 2) {
      firstName = parts[0];
      lastName = parts[1];
    }
  }

  // setter
  set fullName(String name) {
    setFullName(name);
  }
}
