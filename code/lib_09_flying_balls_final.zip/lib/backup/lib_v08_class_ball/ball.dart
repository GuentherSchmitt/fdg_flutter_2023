class Ball {
  static double speedFactor = 1;
  double leftYellow = 50;
  double topYellow = 100;
  double diameter = 50;
  double speedX = 2;
  double speedY = 2;

  move(double stackWidth, double stackHeight) {
          leftYellow += speedX * speedFactor;
      var maxLeft = stackWidth - diameter;
      if (leftYellow > maxLeft) {
        leftYellow = maxLeft;
        speedX = -speedX;
      }
      if (leftYellow < 0) {
        leftYellow = 0;
        speedX = -speedX;
      }

      topYellow += speedY * speedFactor;
      var maxTop =
          stackHeight - diameter;
      if (topYellow > maxTop) {
        topYellow = maxTop;
        speedY = -speedY;
      }
      if (topYellow < 0) {
        topYellow = 0;
        speedY = -speedY;
      }

  }
}