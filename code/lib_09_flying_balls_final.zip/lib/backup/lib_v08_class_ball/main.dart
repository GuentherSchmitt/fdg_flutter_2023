// ignore_for_file: avoid_print

import 'dart:async';

import 'package:flutter/material.dart';

import 'ball.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(home: MainPage());
  }
}

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  double marginRight = 0;
  double marginBottom = 0;
  double borderWidth = 10;
  Color greenColor = Colors.green;
  double leftGreen = 200;
  double topGreen = 150;
  var ball = Ball();

  @override
  void initState() {
    Timer.periodic(const Duration(milliseconds: 20), timerCallback);
    super.initState();
  }

  void timerCallback(Timer timer) {
    var screenWidth = MediaQuery.of(context).size.width;

    setState(() {
      var stackWidth = screenWidth - marginRight - 2 * borderWidth;
      var stackHeight = getMainBoxHeight() - marginBottom - 2 * borderWidth;
      ball.move(stackWidth, stackHeight);
        });
  }

  double getMainBoxHeight() {
    var screenHeight = MediaQuery.of(context).size.height;
    return screenHeight - 150;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        centerTitle: true,
        title: const Text("Flying Balls"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            //Expanded(
            SizedBox(
              height: getMainBoxHeight(),
              child: GestureDetector(
                onPanUpdate: (details) {
                  setState(() {
                    marginRight -= details.delta.dx;
                    if (marginRight < 0) {
                      marginRight = 0;
                    }
                    marginBottom -= details.delta.dy;
                    if (marginBottom < 0) {
                      marginBottom = 0;
                    }
                  });
                },
                child: Container(
                    margin:
                        EdgeInsets.fromLTRB(0, 0, marginRight, marginBottom),
                    height: 600,
                    decoration: BoxDecoration(
                        color: Colors.black,
                        border:
                            Border.all(color: Colors.grey, width: borderWidth)),
                    child: Stack(
                      children: [
                        Positioned(
                            top: topGreen,
                            left: leftGreen,
                            child: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    greenColor = Colors.red;
                                  });
                                },
                                onPanUpdate: (details) {
                                  setState(() {
                                    leftGreen += details.delta.dx;
                                    topGreen += details.delta.dy;
                                  });
                                },
                                child: Container(
                                  width: 100,
                                  height: 150,
                                  color: greenColor,
                                ))),
                        Positioned(
                            top: ball.topYellow,
                            left: ball.leftYellow,
                            child: Container(
                              decoration: const BoxDecoration(
                                color: Colors.yellow,
                                shape: BoxShape.circle,
                              ),
                              width: ball.diameter,
                              height: ball.diameter,
                            )),
                      ],
                    )),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.lightBlue,
                          foregroundColor: Colors.white),
                      onPressed: () {},
                      child: const Text("Reset")),
                  Slider(
                    min: 0,
                    max: 5,
                    value: Ball.speedFactor,
                    onChanged: (value) {
                      setState(() {
                        Ball.speedFactor = value;
                      });
                    },
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
