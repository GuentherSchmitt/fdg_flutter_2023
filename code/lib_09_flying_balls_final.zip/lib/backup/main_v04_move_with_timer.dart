// ignore_for_file: avoid_print

import 'dart:async';

import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(home: MainPage());
  }
}

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  double leftYellow = 50;
  double widthYellow = 200;
  double speedX = 2;
  double marginRight = 20;
  double borderWidth = 10;

  @override
  void initState() {
    Timer.periodic(const Duration(milliseconds: 20), timerCallback);
    super.initState();
  }

  void timerCallback(Timer timer) {
    var screenWidth = MediaQuery.of(context).size.width;

    setState(() {
      leftYellow += speedX;

      var maxLeft = screenWidth - marginRight - widthYellow - 2 * borderWidth;
      if (leftYellow > maxLeft) {
        leftYellow = maxLeft;
        speedX = -speedX;
      }

      // for vertical movement use getMainBoxHeight() instead of screenWidth

      if (leftYellow < 0) {
        leftYellow = 0;
        speedX = -speedX;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    var screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        centerTitle: true,
        title: const Text("Flying Balls"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            //Expanded(
            SizedBox(
              height: screenHeight - 150,
              child: Container(
                  margin: EdgeInsets.fromLTRB(0, 0, marginRight, 0),
                  height: 600,
                  decoration: BoxDecoration(
                      color: Colors.black,
                      border: Border.all(color: Colors.grey, width: borderWidth)),
                  child: Stack(
                    children: [
                      Positioned(
                          top: 150,
                          left: 200,
                          child: Container(
                            width: 100,
                            height: 150,
                            color: Colors.green,
                          )),
                      Positioned(
                          top: 100,
                          left: leftYellow,
                          child: Container(
                            width: widthYellow,
                            height: 100,
                            color: Colors.yellow,
                          )),
                    ],
                  )),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.lightBlue,
                          foregroundColor: Colors.white),
                      onPressed: () {},
                      child: const Text("Reset")),
                  Slider(
                    min: -199,
                    max: 300,
                    value: leftYellow,
                    onChanged: (value) {
                      setState(() {
                        leftYellow = value;
                      });
                    },
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
