// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, avoid_print

import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  void pressedHandler() {
    print("in onPressed");
  }

  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      home: Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Text('Hello World!!!!', style: TextStyle(color: Colors.red)),
              Text('Hello World!', style: TextStyle(color: Colors.blue)),
              OutlinedButton(onPressed: pressedHandler, child: Text("press me"))
            ],
          ),
        ),
      ),
    );
  }
}
