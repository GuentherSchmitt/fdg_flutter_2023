// ignore_for_file: unused_local_variable

void main(List<String> args) {
  //foo(null);     // error: The argument type 'Null' can't be assigned to the parameter type 'String'.
  foo1(null);
  foo2(null);      // prints "null"
  foo2("Hello");   // prints "hello"
}

void foo(String s) {
  print(s.toLowerCase());
}

void foo1(String? s) {
  //print(s.toLowerCase());   // error: The method 'toLowerCase' can't be unconditionally invoked ...
}

void foo2(String? s) {
  print(s?.toLowerCase());               
  
  //String lower = s?.toLowerCase();     // compile-error
  String? lower = s?.toLowerCase();  

  if (s == null) {
    return;
  }
  // compiler knows that s is not null now !
  String lower1 = s.toLowerCase();
}
