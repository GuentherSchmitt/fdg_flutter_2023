
void main () {
  // A small test with "runes" copied from https://www.flutter.de/artikel/dart-basics-datentypen
  // Hint: to select an emoji in Windows, type "WindowsKey+."
  // A list of emojis and their Unicode representation can be found at 
  // https://unicode.org/emoji/charts/full-emoji-list.html

  var klatschen = '\u{1f44f}'; // 👏
  print("$klatschen ❤🧡💛😍");
  Runes input = new Runes('\u{1f600}' '\u{1f499}' '\u{1f44d}' '\u{1f61b}');
  print(String.fromCharCodes(input)); // 😀💙👍
}