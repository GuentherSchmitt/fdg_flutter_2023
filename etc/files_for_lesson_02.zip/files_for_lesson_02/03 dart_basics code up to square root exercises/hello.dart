void main(List<String> args) {
  print('Hello World!');

  // for loop like in C:
  for (int i = 0; i < args.length; i++) {
    print(args[i]);
  }

  // alternative for loop:
  for (var arg in args) {
    print(arg);
  }
}
