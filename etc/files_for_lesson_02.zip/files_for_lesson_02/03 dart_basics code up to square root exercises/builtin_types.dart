void main() {
  // --- int and double ---

  int i = 23;
  double d = 24;

  // double d1 = 2.34;
  // int i1 = 2.34;      // double cannot be assigned to int

  // d = i;              // int cannot be assigned to double
  // d = i.toDouble();

  // i = d;              // double cannot be assigned to int
  // i = d.toInt();

  // d = i + i;          // int cannot be assigned to double
  // d = i + d;
  // i = i + d;          // double cannot be assigned to int

  // int i2 = i + i1;
  // double d2 = i + d;
  // i3 = i + d1;         // double cannot be assigned to int

  // --- String and String-Interpolation ---

  String s = 'hello world';

  s = "It's me"; // you can either use " or ' to surround strings
  s = 'It\'s me'; // backslash is the "escape character" in strings
  s = 'c:\\flutter\\sdk'; // \\ stands for \ inside the string
  s = '1st line\n2nd line'; // \n is new line for multi-line strings

  s = "hello";
  s = s + " world"; // "hello world"
  s += "!"; // "hello world!""

  d = 1.234567;
  //s = d;               // double cannot be assigned to string
  s = d.toString();

  s = "d is " + d.toString(); // "d is 1.234567"
  s = "d is " + d.toStringAsFixed(2); // "d is 1.23"

  // next lines use String-Interpolation:
  s = "d is $d !"; // "d is 1.234567 !"
  s = "d + 1 is ${d + 1} !"; // "d + 1 is 2.234567 !"
  s = "d is ${d.toStringAsFixed(1)}"; // "d is 1.2"

  // --- special functions for int ---

  i = 30;
  print(i.toRadixString(16));
  print(i.toRadixString(8));
  print(i.toRadixString(7));
  print(i.toRadixString(2));
  i = i >> 1;
  // next line makes the same as last line:
  // i >>= 1;
  print(i.toRadixString(2));
  print(i);
  i = i << 3;
  print(i.toRadixString(2));
  print(i);

  // --- bool ---

  bool b = false;
  print("not b is ${!b}"); // "not b is true"

  b = (i > -1);
  b = (i > -1) && (i < 1);
  b = (i < -1) || (i > 1);

  String result;
  if (i.isEven) {
    result = "gerade";
  } else {
    result = "ungerade";
  }
  print(result);

  // shorter with a conditional expression

  print(i.isEven ? "gerade" : "ungerade");

  // --- variable declaration with var ---

  // int x = 1;
  // double y = 1.23;
  // List<String> names = ["Franz", "Frank"];

  var x = 1;
  var y = 1.23;
  var names = ["Franz", "Frank"];

  print(x.runtimeType);
  print(y.runtimeType);
  print(names.runtimeType);

  for (var name in names) {
    print(name);
  }

  // --- final variables ---

  final int myInt = 1;
  final List<String> myList = ["a", "bb"];

  //myInt = 5;             // error: The final variable 'myInt' can only be set once.

  //myList = ["x", "yy"];  // error: The final variable 'myList' can only be set once.
  myList.add("ccc"); // that's ok, we do not assign a new list

  final myDouble = 1.5; // short for "final double myDouble1 = 1.5;"

  print(myInt.runtimeType);
  print(myDouble.runtimeType);
  print(myList.runtimeType);

  // to avoid warnings "variable not used" above
  print("$myInt $myDouble");

  // --- difference final vs. const ---

  //const int cInt;        // error: The constant 'cInst' must be initialized.

  const int cInt1 = 23;

  final int fInt;

  fInt = 23;

  //fInt = 1;

  //cInt1 = 1;

  // to avoid warnings "variable not used" above
  print("$cInt1 $fInt");

  // --- ceil (Decke) and floor (Boden) for num ---

  num n = 3;
  print(n.toStringAsFixed(2));
  num n1 = -1.6;
  num n2 = 1.6;
  print("n1: $n1, ceil: ${n1.ceil()}, floor: ${n1.floor()}");
  print("n2: $n2, ceil: ${n2.ceil()}, floor: ${n2.floor()}");

  // --- parse strings for integers and nullable types ---/*  */

  print(int.tryParse("2"));
  print(int.tryParse("a"));

  int? parsed = int.tryParse("2");
  if (parsed != null) {
    print(parsed.isEven);
  }

  // --- for the slide "what is defined where" ---

  Object obj = 1;

  print(obj.hashCode);
  print(1.hashCode);
  print(1.hashCode);
  print(2.hashCode);
  print((3.1).hashCode);
  print("hello".hashCode);
  print("hello".hashCode);
  print("hellox".hashCode);
}
